# C++ example

run with `make run`
